<?php
/**
 * Plugin Name: SV Väder
 * Description: Visar aktuellt väder för vald plats (Open-Meteo). Kortkod [sv_vader] och Gutenberg-block.
 * Version: 1.0.0
 * Author: Nyttodata Väst AB
 * Text Domain: sv-vader
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

define('SV_VADER_VER', '1.0.0');
define('SV_VADER_DIR', plugin_dir_path(__FILE__));
define('SV_VADER_URL', plugin_dir_url(__FILE__));

require_once SV_VADER_DIR . 'includes/class-sv-vader.php';
require_once SV_VADER_DIR . 'includes/admin-page.php';

final class SV_Vader_Plugin {
    public function __construct() {
        add_action('init', [$this, 'register_shortcodes']);
        add_action('init', [$this, 'register_block']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_public_assets']);
        add_action('plugins_loaded', [$this, 'load_textdomain']);
        add_action('admin_menu', 'sv_vader_register_settings_page');
    }

    public function load_textdomain() {
        load_plugin_textdomain('sv-vader', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function enqueue_public_assets() {
        wp_enqueue_style('sv-vader-style', SV_VADER_URL . 'assets/style.css', [], SV_VADER_VER);
    }

    public function register_shortcodes() {
        add_shortcode('sv_vader', [$this, 'render_shortcode']);
    }

    public function render_shortcode($atts = []) {
        $opts = get_option('sv_vader_options', [
            'default_ort' => 'Stockholm',
            'cache_minutes' => 10,
            'show_wind' => 1,
        ]);

        $a = shortcode_atts([
            'ort' => $opts['default_ort'] ?? 'Stockholm',
            'lat' => '',
            'lon' => '',
            'show' => 'temp,wind,icon', // kommaseparerat
            'class' => '',
        ], $atts, 'sv_vader');

        $show = array_map('trim', explode(',', strtolower($a['show'])));

        $api = new SV_Vader_API(intval($opts['cache_minutes'] ?? 10));
        $res = $api->get_current_weather($a['ort'], $a['lat'], $a['lon']);

        if (is_wp_error($res)) {
            return '<em>' . esc_html($res->get_error_message()) . '</em>';
        }

        $temp = isset($res['temp']) ? round($res['temp']) : null;
        $wind = isset($res['wind']) ? round($res['wind']) : null;
        $wcode = $res['code'] ?? null;
        $icon_url = $api->map_icon_url($wcode);

        ob_start(); ?>
        <div class="sv-vader <?php echo esc_attr($a['class']); ?>">
            <?php if (!empty($res['name'])): ?>
                <div class="svv-ort"><?php echo esc_html($res['name']); ?></div>
            <?php endif; ?>
            <div class="svv-row">
                <?php if (in_array('icon', $show, true) && $icon_url): ?>
                    <img class="svv-icon" src="<?php echo esc_url($icon_url); ?>" alt="" loading="lazy">
                <?php endif; ?>
                <?php if (in_array('temp', $show, true) && $temp !== null): ?>
                    <div class="svv-temp"><?php echo esc_html($temp); ?>°C</div>
                <?php endif; ?>
            </div>
            <div class="svv-meta">
                <?php if (in_array('wind', $show, true) && $wind !== null): ?>
                    <span class="svv-wind"><?php echo esc_html(sprintf(__('Vind: %s m/s', 'sv-vader'), $wind)); ?></span>
                <?php endif; ?>
                <?php if (!empty($res['desc'])): ?>
                    <span class="svv-desc"><?php echo esc_html($res['desc']); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function register_block() {
        // Server-renderat block – ett attribut-API utan buildsteg
        register_block_type('sv/vader', [
            'api_version' => 2,
            'render_callback' => function($attrs, $content) {
                $atts = [
                    'ort' => $attrs['ort'] ?? '',
                    'lat' => $attrs['lat'] ?? '',
                    'lon' => $attrs['lon'] ?? '',
                    'show' => $attrs['show'] ?? 'temp,wind,icon',
                    'class' => 'is-block',
                ];
                return $this->render_shortcode($atts);
            },
            'attributes' => [
                'ort' => ['type' => 'string', 'default' => 'Stockholm'],
                'lat' => ['type' => 'string', 'default' => ''],
                'lon' => ['type' => 'string', 'default' => ''],
                'show' => ['type' => 'string', 'default' => 'temp,wind,icon'],
            ],
            'style' => 'sv-vader-style',
            'editor_script' => null, // rent serverblock (syns i “Lägga till block” som “SV Väder”)
            'title' => __('SV Väder', 'sv-vader'),
            'description' => __('Visar aktuellt väder (Open-Meteo).', 'sv-vader'),
            'category' => 'widgets',
            'icon' => 'cloud',
            'keywords' => ['väder', 'weather', 'klimat'],
        ]);
    }
}

new SV_Vader_Plugin();
